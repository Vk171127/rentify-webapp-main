"use client";

import { Button } from "@/components/ui/button";
import React from "react";
import CreatePropertyForm from "./component/createPropertyForm";

const AddNewProperty = () => {
  return (
   <div>
    <CreatePropertyForm/>
    
   </div>
  );
};

export default AddNewProperty;
