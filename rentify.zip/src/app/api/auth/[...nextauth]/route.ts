import { authOptions } from "@/lib/authOptions";
import NextAuth from "next-auth";

export default NextAuth(authOptions);
