
import { redirect } from "next/navigation";
// import { authOptions } from "./api/auth/[...nextauth]/route";

import Property from "@/models/property";
import { Button } from "@/components/ui/button";
import Link from "next/link";
import PropertyCarousel from "./components/PropertyCarousel";
import { connectMongoDB } from "@/lib/mongoDb";

export default async function Home() {
  // const session = await getServerSession(authOptions);

    await connectMongoDB();
    const PropertyData= await Property.find({})
      .limit(4)
      .sort([["createdAt", "descending"]]);

      // console.log(PropertyData)

  // if (session) redirect("/dashboard");

  return (
    <main >
    {/* <Navbar /> */}
    <div className="w-full flex justify-center my-4">

    <div className="flex flex-col w-[55%] justify-center items-center space-y-4">
    <div className="self-center text-3xl text-emerald-500 ">Recently posted</div>
    <div className="w-[5%] self-end">
    <Button className="py-2 bg-emerald-500"><Link href="/viewProperty" >View All</Link></Button>
    </div>
    </div>
    </div>
    <div className="w-[95%]">
      <PropertyCarousel propertyData={PropertyData} />
    </div>
  </main>
  );
}