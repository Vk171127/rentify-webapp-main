
import React from "react";
import Property from "@/models/property";
import { connectMongoDB } from "@/lib/mongoDb";
import Navbar from "@/components/Navbar";
import FilterSection from "../viewProperty/components/FilterSection";

const PropertyDisplay = async () => {
    await connectMongoDB();
    const PropertyData= await Property.find({})//const PropertyData= await Property.find({ email:creatoremail})
  return (
    <div>
      <div> <Navbar/></div>
    <div className="flex flex-col m-6">
     
      <FilterSection propertyData={PropertyData} />
    </div>
    </div>
  );
};

export default PropertyDisplay;

