import { connectMongoDB } from "@/lib/mongoDb";
import Property from "@/models/property";
import { revalidatePath } from "next/cache";
import { z } from "zod";

export async function deletePropertyAction(id: unknown) {
    const res = z
      .string()
      .min(1, "ID is required to delete")
      .safeParse(id);
    if (!res.success) {
        console.log(res.error.issues);
        return {
          message: res.error.issues[0].message,
          success: false,
          issues: res.error.issues,
        };
      }
    try {
      await connectMongoDB();
      const propertyDeleted = await Property.findOneAndDelete({
        _id: res.data,
      });
      if (!propertyDeleted) {
        return {
          message: "Property not found",
          success: false,
        };
      } else {
        revalidatePath(`/myProperty`);
        return {
          message: "Property deleted successfully",
          success: true,
        };
      }
    } catch (e) {
      return { message: "Failed to delete", success: false };
    }
  }
  