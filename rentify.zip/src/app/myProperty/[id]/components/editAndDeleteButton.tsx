import { Button } from '@/components/ui/button'
import Link from 'next/link'
import React from 'react'
import { deletePropertyAction } from './deletePropertyAction'

const EditAndDeleteButton = (id:any) => {

    async function HandleDelete(id:string) {
        const propertyDeleted = await deletePropertyAction(id)
    }

  return (
    <div><Button><Link href={`/myProperty/${id}/editProperty`}>Edit</Link></Button>
    <button onClick={()=>HandleDelete(id)} >Delete</button></div>
  )
}

export default EditAndDeleteButton