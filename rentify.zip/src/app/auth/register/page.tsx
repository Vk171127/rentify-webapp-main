import { RegisterForm } from "./components/register-form";

export default function Register() {
  return <RegisterForm />;
}