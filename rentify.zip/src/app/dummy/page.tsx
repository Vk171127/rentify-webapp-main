import React from "react";

import { PropertyZodSchemaType } from "@/zodSchema/propertyZodSchema";
import MyCard from "@/components/MyCard";

const dummyPropertyData: PropertyZodSchemaType = {
  _id: "60d5ec49f6d5a29f8e612345",
  title: "Luxurious 2BHK Apartment",
  description: "A spacious and luxurious 2-bedroom apartment with modern amenities.",
  type: "Apartment",
  address: {
    doorNo: "123",
    street: "Main Street",
    area: "Downtown",
    city: "Metropolis",
    state: "Stateville",
    pincode: "123456",
  },
  rent: 45000,
  deposit: 100000,
  bedrooms: 2,
  bathrooms: 2,
  amenities: "Swimming Pool, Gym, Park, 24/7 Security",
  images: ["https://via.placeholder.com/150", "https://via.placeholder.com/150"],
  creatorEmail: "owner@example.com",
};

const PropertyPage = () => {
  return (
    <div>
      <MyCard propertyData={dummyPropertyData} />
    </div>
  );
};

export default PropertyPage;
